#define THE_TYPE long double
#define THE_SIZE 128
#define INTEGRAL_TYPE 0
