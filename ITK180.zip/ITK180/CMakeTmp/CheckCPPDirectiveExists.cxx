#include <iostream>

int main()
{
std::cout << __FUNCTION__;
  return 0;
}
